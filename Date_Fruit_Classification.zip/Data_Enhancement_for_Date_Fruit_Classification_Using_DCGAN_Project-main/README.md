# Data_Enhancement_for_Date_Fruit_Classification_Using_DCGAN_Project
The aim of this project to data enhancement for date fruit classification using state-of- the-art techniques;  augmented date fruits dataset (Sukkri, Ajwa and Sagei)was developed using deep convolutional generative adversarial networks techniques (DCGAN). Since evaluate the performance of DCGAN using Keras and MobileNet models. 



## License
**Free Coding.
